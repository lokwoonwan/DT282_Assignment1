# Dt282-OOP
Object Orientated Programming Year2

My assignment is on Beijing’s air pollution. Data is taken from the US Government.
It shows the level of pollution at an hourly rate in April 2014.

I plan on drawing a line graph and comparing Dublin’s air pollution to Beijing’s air pollution.

I plan on drawing a pie chart to find the highest air pollution on any given day.